rootProject.name = "MidiaIndoorPlayer"
include(":app")
